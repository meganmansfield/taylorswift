'''
taylorswift

A python package to match your current mood and relationship status to a suitable Taylor Swift song.
'''

__version__= "0.1.0"
__author__= "Megan Mansfield"